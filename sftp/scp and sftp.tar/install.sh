mkdir sftp
mv sftp.tar sftp/sftp.tar
cd sftp
tar -xf sftp.tar
rm sftp.tar
cp -r * /
cd ..
rm -r sftp